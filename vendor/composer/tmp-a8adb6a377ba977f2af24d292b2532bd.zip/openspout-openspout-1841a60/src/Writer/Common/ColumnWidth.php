<?php

declare(strict_types=1);

namespace OpenSpout\Writer\Common;

/**
 * @internal
 */
final readonly class ColumnWidth
{
    /**
     * @param positive-int $start
     * @param positive-int $end
     */
    public function __construct(
        public int $start,
        public int $end,
        public float $width,
    ) {}
}
